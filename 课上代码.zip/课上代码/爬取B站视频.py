"""


@explain: 1.安装requests pip install requests
          2.安装re pip install re
          3.安装os pip install os
          4.需要下载ffmpeg 地址:https://ffmpeg.org/download.html#build-windows,添加环境变量
          5.url_path:b站视频链接列表
          6.download_folder:下载到的目录

"""

# from selenium import webdriver  # c
import requests
import re
import time
import os


class BilibiliSpider(object):

    def __init__(self, url, folder, cookie=False):
        self.url_path = url
        self.download_folder = str(folder)
        if not cookie:
            self.cookie = """buvid3=64238340-C304-CFB8-01EB-9A9A1E87B87547755infoc; b_nut=1716733847; CURRENT_FNVAL=4048; _uuid=CBE6FE52-BB11-310BE-16CE-3ED110361AB10847988infoc; buvid_fp=1c711a226c6a1dabf1ff71f6924c15e4; buvid4=DA1EF69D-61E3-B178-9EB2-06ED206134E150559-024052614-fGKeACqCRaxxwBcpIU8k%2BQ%3D%3D; rpdid=|(u)~lRR~mu|0J'u~uY~JJ)lu; b_lsid=9EFADBF5_1901720CE13; bsource=search_google; enable_web_push=DISABLE; header_theme_version=CLOSE; home_feed_column=5; browser_resolution=1920-959; bili_ticket=eyJhbGciOiJIUzI1NiIsImtpZCI6InMwMyIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MTg2MzQxNDYsImlhdCI6MTcxODM3NDg4NiwicGx0IjotMX0._dYyflC8c-9GQbMl-ivjOspR-bITkEBWKljSnTMuWCU; bili_ticket_expires=1718634086; sid=7h9fopr0"""
            # self.cookie = """buvid3=A4F7BB10-31A4-011D-8913-4F959A582E7707769infoc; b_nut=1668678707; _uuid=2A758284-8DCB-13AE-8AE4-A510DF93102C2207758infoc; buvid4=A4F6A536-563B-2EA6-C4DA-D987D052DE6309439-022111717-JjFnVEThOev2RSNiO3PCPA%3D%3D; i-wanna-go-back=-1; nostalgia_conf=-1; CURRENT_FNVAL=4048; rpdid=|(k|lRRuYlu)0J'uYY)~l|lu|; fingerprint=e540dbc30aae95e57e47a9e4b68e8137; buvid_fp_plain=undefined; DedeUserID=374295422; DedeUserID__ckMd5=04924f744ab8f2f2; b_ut=5; LIVE_BUVID=AUTO6116688366332570; b_lsid=5C31883D_1849338D512; innersign=1; buvid_fp=A4F7BB10-31A4-011D-8913-4F959A582E7707769infoc; SESSDATA=3356b644%2C1684469709%2C765c1%2Ab1; bili_jct=6c6a0b7e438bd8d3ca1b7465e163aebe; bp_video_offset_374295422=730482823802126300; sid=7m1skkpf; PVID=1"""
            # self.cookie = """buvid3=D1987370-7D9B-1626-3E05-8B68B75059EE27901infoc; b_nut=1664331327; i-wanna-go-back=-1; b_ut=7; _uuid=8D951AB9-C1F8-C2D7-239E-EA3D5105E6E6F29697infoc; buvid4=7CDF08E8-F2C4-667C-02E4-F136BB3982D532616-022092810-N4V8KQ2H012ueJhBxXNSQg%3D%3D; LIVE_BUVID=AUTO2416643313494488; rpdid=|(~YRlk|kk)0J'uYYRJJuRRR; PVID=1; fingerprint=e540dbc30aae95e57e47a9e4b68e8137; buvid_fp_plain=undefined; is-2022-channel=1; nostalgia_conf=-1; b_lsid=64918475_183B720AC10; SESSDATA=261ffae1%2C1680778902%2C5fef2%2Aa1; bili_jct=df709e28ef622e3eee752c5b433e2c9c; DedeUserID=374295422; DedeUserID__ckMd5=04924f744ab8f2f2; buvid_fp=112b867929b54bdf7e00b304b4cfe8db; innersign=1; CURRENT_FNVAL=4048; theme_style=light; sid=8dyglbacsec-ch-ua: " Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v='102'"""


        else:
            self.cookie = self.get_cookies()
        self.headers = {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) \
            AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",

            "referer": "https://www.bilibili.com/video/BV1F34y1j7nm?t=143.0& \
            vd_source=a7e1ad19ee229e4da690c8218eead721",
            "cookie": self.cookie

        }

    @staticmethod
    def get_cookies():
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get("https://www.bilibili.com")
        print("请扫码登录")
        while True:
            res = input("登录好了吗,好了请按ok:")
            if res == "ok":
                time.sleep(1)
                break
        cookie_tag = driver.get_cookies()
        cookie = ""

        for i in cookie_tag:
            if cookie:
                cookie = cookie + ";"
            res = i['name'] + '=' + i['value']
            cookie = cookie + res
        driver.quit()
        return cookie

    def get_bilibili_html(self, url):
        resp = requests.get(url=url, headers=self.headers).text
        # resp = resp.encode("gbk","ignore").decode("gbk","ignore")
        obj = re.compile(r'"baseUrl":"(.*?)"', re.S)
        video_url = obj.findall(resp)
        print(video_url)
        return video_url

    def video_audio_download(self, video_url):
        # 视频(第一个视频清晰度最高)
        resp_video = requests.get(video_url[0], headers=self.headers)
        # 音频 (最后一个url只有音频)
        resp_audio = requests.get(video_url[-1], headers=self.headers)
        video_download_file_path = self.download_folder + "0.mp4"
        audio_download_file_path = self.download_folder + "0.mp3"
        with open(video_download_file_path, mode="wb") as f:
            f.write(resp_video.content)

        with open(audio_download_file_path, mode="wb") as f:
            f.write(resp_audio.content)
        return video_download_file_path, audio_download_file_path

    def compose(self, video_file, audio_file):
        file_name = self.download_folder + str(time.time()).replace(".", "") + ".mp4"
        os.system(f'ffmpeg -i {video_file} -i {audio_file} -c copy "{file_name}"')
        os.remove(video_file)
        os.remove(audio_file)

    def main(self):
        surplus_number = len(self.url_path)
        downloading_number = 1
        for i in self.url_path:
            surplus_number -= 1
            print(f"正在下载第{downloading_number}个视频,还剩{surplus_number}个视频")
            video_url = self.get_bilibili_html(i)
            v, a = self.video_audio_download(video_url)
            self.compose(v, a)
            time.sleep(1)
            downloading_number += 1


if __name__ == '__main__':
    url_path = [
                "https://www.bilibili.com/video/BV1DeKHeDETj/?spm_id_from=333.1007.tianma.2-3-6.click&vd_source=513740106383589134a741139796a91d"

    ]

    download_folder = "C:\\Users\\ASUS\\Desktop\\blibli\\"

    b_obj = BilibiliSpider(url_path, download_folder, cookie=False)
    b_obj.main()
    print("下载完毕")
