
import random
import time

import PIL.ImageGrab
import pyautogui
import win32api
import win32con
import win32gui
import win32ui
from PIL import Image as Img
import numpy as np

#截取游戏窗口图像
def window_capture(hwnd,filename, right,bottom):
    hwndDC = win32gui.GetWindowDC(hwnd)    # 根据窗口的DC获取mfcDC
    mfcDC = win32ui.CreateDCFromHandle(hwndDC)    # mfcDC创建可兼容的DC
    saveDC = mfcDC.CreateCompatibleDC()    # 创建bigmap准备保存图片
    saveBitMap = win32ui.CreateBitmap()    # 获取显示屏信息
    MoniterDev = win32api.EnumDisplayMonitors(None, None)
    w = MoniterDev[0][2][2]
    h = MoniterDev[0][2][3]    # print w,h（显示屏分辨率）　　　#图片大小
    saveBitMap.CreateCompatibleBitmap(mfcDC, w, h)
    saveDC.SelectObject(saveBitMap)
    saveDC.BitBlt((12, 179), (right, bottom), mfcDC, (12, 179), win32con.SRCCOPY)
    saveBitMap.SaveBitmapFile(saveDC, filename)
#判断两个相似的图像
def find_two_similiar_fig(image1, image2):
    grid = 10
    hash_square_f = 0
    hash_f = 0
    image1 = image1.resize((grid, grid))
    image2 = image2.resize((grid, grid))
    for i in range(grid ** 2):
        f1 = image1.getpixel((int(i/grid), i % grid))
        f2 = image2.getpixel((int(i / grid), i % grid))
        hash_square_f += np.sqrt((f1[0]-f2[0])**2+(f1[1]-f2[1])**2+(f1[2]-f2[2])**2)/2
    hash_f = hash_square_f/(grid ** 2)
    if hash_f <= 5:
        flag = 1
    else:
        flag = 0
    return flag
#判断图像块是否为地板
def blank_block(image):
    hash_square_f = 0
    hash_f = 0
    for k in [14, 16, 18]:
        f = image.getpixel((k, k))
        hash_square_f += np.sqrt((f[0] - 48) ** 2 + (f[1] - 76) ** 2 + (f[2] - 112) ** 2) / 2
    hash_f = hash_square_f / 3
    if hash_f <= 3:
        flag = 1
    else:
        flag = 0
    return flag
#将图像转换为数字矩阵
def image_to_maxtrix(image):
    row_num = 11
    col_num = 19
    image_map = {}
    grid_pos = {}
    grid_hash = {}
    map = {}
    temp_type_matrix = [[0 for col in range(19)]for row in range(11)]
    for row in range(row_num):
        grid_pos[row] = {}
        for col in range(col_num):
            grid_left = col * grid_width
            grid_right = grid_left+grid_width
            grid_top = row * grid_height
            grid_bottom = grid_top + grid_height
            grid_image = image.crop((grid_left, grid_top, grid_right, grid_bottom))
            map[row*19+col] = grid_image
    blank = {}
    count_same = 0
    count_same_dict =dict.fromkeys(range(209), 0)
    count_dict = dict.fromkeys(range(209), 0)
    count = 0
    for i in range(209):
        count_dict[i] = count
        count_same_dict[i] = count_same
        if blank_block(map[i]):
            temp_type_matrix[int(i / 19)][i % 19] = 0
            count += 1
            blank.setdefault(i, [])
            continue
        for j in range(i+1):
            if blank.__contains__(j):
                continue
            if find_two_similiar_fig(map[j], map[i]) and j != i:
                temp_type_matrix[int(i/19)][i % 19] = j-count_dict[j]+1-count_same_dict[j]
                count_same += 1
                break
            if j == i:
                temp_type_matrix[int(i/19)][i % 19] = i-count-count_same+1
                break

    return temp_type_matrix
#判断两两格子是否可消
def verifying_connectivity(x1, y1, x2, y2, matrix):
    max_y1 = y1
    ROW_NUM =11
    COL_NUM =19
    while max_y1 + 1 < ROW_NUM and matrix[max_y1 + 1][x1] == 0:  # 如果第一格子不在最后一行而且他下面一个格子为空，继续往下搜
        max_y1 += 1
    min_y1 = y1
    while min_y1 - 1 >= 0 and matrix[min_y1 - 1][x1] == 0:  # 如果第一格子不在最上一行而且他上面一个格子为空，继续往下搜
        min_y1 -= 1

    max_y2 = y2
    while max_y2 + 1 < ROW_NUM and matrix[max_y2 + 1][x2] == 0:  # 如果第二格子不在最后一行而且他下面一个格子为空，继续往下搜
        max_y2 += 1
    min_y2 = y2
    while min_y2 - 1 >= 0 and matrix[min_y2 - 1][x2] == 0:  # 如果第二格子不在最上一行而且他上面一个格子为空，继续往下搜
        min_y2 -= 1
    rg_min_y = max(min_y1, min_y2)
    rg_max_y = min(max_y1, max_y2)
    if rg_max_y >= rg_min_y:
        for index_y in range(rg_min_y, rg_max_y + 1):  # 说明竖向有可能有连接区域
            min_x = min(x1, x2)
            max_x = max(x1, x2)
            flag = True
            for index_x in range(min_x + 1, max_x):  # 每一行看竖向可能连接区域是否没有格子阻挡
                if matrix[index_y][index_x] != 0:
                    flag = False
                    break
            if flag:
                return True
    max_x1 = x1
    while max_x1 + 1 < COL_NUM and matrix[y1][max_x1 + 1] == 0:
        max_x1 += 1
    min_x1 = x1
    while min_x1 - 1 >= 0 and matrix[y1][min_x1 - 1] == 0:
        min_x1 -= 1

    max_x2 = x2
    while max_x2 + 1 < COL_NUM and matrix[y2][max_x2 + 1] == 0:
        max_x2 += 1
    min_x2 = x2
    while min_x2 - 1 >= 0 and matrix[y2][min_x2 - 1] == 0:
        min_x2 -= 1
    rg_min_x = max(min_x1, min_x2)
    rg_max_x = min(max_x1, max_x2)
    if rg_max_x >= rg_min_x:
        for index_x in range(rg_min_x, rg_max_x + 1):
            min_y = min(y1, y2)
            max_y = max(y1, y2)
            flag = True
            for index_y in range(min_y + 1, max_y):
                if matrix[index_y][index_x] != 0:
                    flag = False
                    break
            if flag:
                return True
    return False
#连接可以消除的两个格子
def find_and_connect():
    for key in fig_map:
        arr_temp = fig_map[key]
        arr_len = len(arr_temp)
        for index1 in range(arr_len):
            point1 = arr_temp[index1]
            x1 = point1[0]
            y1 = point1[1]
            for index2 in range(index1+1,arr_len):
                point2 = arr_temp[index2]
                x2 = point2[0]
                y2 = point2[1]
                if verifying_connectivity(x1, y1, x2, y2, matrix):
                    arr_temp.remove(point1)
                    arr_temp.remove(point2)
                    matrix[y1][x1] = 0
                    matrix[y2][x2] = 0
                    if arr_len == 2:
                        fig_map.pop(key)
                    return y1, x1, y2, x2
#鼠标自动化点击两个可消的格子
def execute_one_step(one_step):
    from_row, from_col, to_row, to_col = one_step

    from_x = game_area_left + (from_col + 0.5) * grid_width
    from_y = game_area_top + (from_row + 0.5) * grid_height

    to_x = game_area_left + (to_col + 0.5) * grid_width
    to_y = game_area_top + (to_row + 0.5) * grid_height

    pyautogui.moveTo(from_x, from_y)
    pyautogui.click()

    pyautogui.moveTo(to_x, to_y)
    pyautogui.click()
#主函数
if __name__ == "__main__":
    COL_NUM = 19  # 列数
    ROW_NUM = 11  # 行数
    screen_width = win32api.GetSystemMetrics(0)
    screen_height = win32api.GetSystemMetrics(1)
    hwnd = win32gui.FindWindow(win32con.NULL, "QQ游戏 - 连连看角色版")
    if hwnd == 0:
        exit(-1)
    else:
        print("找到了")
    win32gui.ShowWindow(hwnd,win32con.SW_RESTORE)
    win32gui.SetForegroundWindow(hwnd)
    window_left, window_top, window_right, window_bottom = win32gui.GetWindowRect(hwnd)
    window_width = window_right - window_left  # 游戏窗口宽度
    window_height = window_bottom - window_top  # 游戏窗口高度
    game_area_left = window_left + 14.0 / 800.0 * window_width  # 游戏连连看可消区域上下左右坐标
    game_area_top = window_top + 181.0 / 600.0 * window_height
    game_area_right = window_left + 603 / 800.0 * window_width
    game_area_bottom = window_top + 566 / 600.0 * window_height
    game_area_width = game_area_right - game_area_left
    game_area_height = game_area_bottom - game_area_top
    # 一个格子宽高
    grid_width = game_area_width / COL_NUM
    grid_height = game_area_height / ROW_NUM
    window_capture(hwnd, 'E://33.jpg', int(game_area_width+50), int(game_area_height))#根据实际调整写出的参数
    game_area_image = PIL.Image.open('E://33.jpg')
    game_area_image = game_area_image.crop((12, 181, 605, 570))
    matrix = image_to_maxtrix(game_area_image)
    fig_map = {}
    for y in range(ROW_NUM):
        for x in range(COL_NUM):
            grid_id = matrix[y][x]
            if grid_id == 0:
                continue
            fig_map.setdefault(grid_id, [])
            fig_map[grid_id].append([x, y])
    print('fig_map:', fig_map)
    pyautogui.PAUSE = 0.1
    print("准备就绪。。。。。。")
    while True:
        one_step = find_and_connect()
        print('one_step:',one_step)
        if not one_step:
            exit(0)
        execute_one_step(one_step)
        time.sleep(random.randint(0, 10) / 1000)


