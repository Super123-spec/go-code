from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import time
import json


def debugger_options():
    # 创建一个 Options 对象，用于配置和启动 Chrome 浏览器时的选项
    chrome_options = Options()
    # 添加一个配置, 指定远程调试地址
    chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
    # 创建一个selenium实例对象
    browser = webdriver.Chrome(options=chrome_options)
    return browser

def input_content_query(browser, content):
    input_query = browser.find_element(By.CSS_SELECTOR, ".hotWords>input")
    input_query.send_keys(content)
    input_query.send_keys(Keys.ENTER)
    time.sleep(1)
    return browser

def mouse_swipe(browser):
    # 使用JavaScript滑动至页面底部
    browser.execute_script("window.scrollTo(0, document.body.scrollHeight);")


def save_data_to_txt(data):
    for item in data:
        with open("../bb.txt", "a", encoding="utf-8") as f:
            f.write(item["品牌"]+"\n")
            f.write(item["详情"]+"\n\n")

def find_li(browser):
    li_list = browser.find_elements(By.CSS_SELECTOR, ".gl-warp>li")
    result = []
    i = 0
    for item in li_list:
        time.sleep(0.5)
        detail = item.find_element(By.CSS_SELECTOR, ".p-img>a")
        detail_url = detail.get_attribute("href")   # 阿 chui b 欧特
        detail.click()
        time.sleep(1.5)

        # 切换标签页
        window_handles = browser.window_handles # 涵斗似
        for handle in window_handles:
            time.sleep(0.5)
            browser.switch_to.window(handle)
            if detail_url == browser.current_url:   # 槛闻特
                print("切换到匹配的标签页:", browser.title)  # 打印匹配的标签页标题
                break

        info = {}
        brand = browser.find_element(By.CSS_SELECTOR, "#parameter-brand>li").text
        li_parameter_list = browser.find_elements(By.CSS_SELECTOR, ".parameter2>li")
        info["品牌"] = brand
        info["详情"] = ""

        for li in li_parameter_list:
            info["详情"] += f"{li.text}\n"
        info["详情"] += "\n"
        result.append(info)
        browser.close()
        window_handles = browser.window_handles
        browser.switch_to.window(window_handles[0])


    return result
def run():
    browser = debugger_options()
    print(111)
    browser = input_content_query(browser, "女包")
    mouse_swipe(browser)
    result = find_li(browser)
    save_data_to_txt(result)

time.sleep(1)
run()