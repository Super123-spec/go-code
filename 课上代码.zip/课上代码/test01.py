#写一个爬虫程序，爬取网站，并生成一个excel文件
import pandas as pd

#1.找一个网站地址
网站地址 = 'https://www.dxsbb.com/news/143353.html'

#2.访问网站
网站内容 = pd.read_html(网站地址,encoding='gbk')[0]

#3.保存在excel里
print(网站内容)
网站内容.to_excel('高校毕业生数量.xlsx',index=0)