"""
[使用模块]: requests >>> pip install requests        <第三方模块>
           parsel >>> pip install parsel            <第三方模块>
           prettytable >>> pip install prettytable  <第三方模块>


"""
import requests  # 第三方的模块
import parsel  # 第三方的模块
import os  # 内置模块 文件或文件夹

filename = '小说\\'
if not os.path.exists(filename):
    os.mkdir(filename)

headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
    'referer': 'https://www.bi01.cc/index/121904/',
    'cookie': 'Hm_lvt_9c5f07b6ce20e3782eac91ed47d1421c=1739781879; HMACCOUNT=ABA2FB17C5592024; Hm_lpvt_9c5f07b6ce20e3782eac91ed47d1421c=1739781945',


}

    

rid = input('输入书名ID：')
link = f'https://www.bi01.cc/index/{rid}/'

html_data = requests.get(url=link, headers=headers).text
selector_2 = parsel.Selector(html_data)
divs = selector_2.css('.listmain dd')
for div in divs:
    title = div.css('a::text').get()
    href = div.css('a::attr(href)').get()
    url = 'https://www.bi01.cc/' + href
    print(url)
    try:
        response = requests.get(url=url, headers=headers)
        selector = parsel.Selector(response.text)
        print(selector)
        # getall 返回的是一个列表 []
        book = selector.css('#chaptercontent::text').getall()
        book = '\n'.join(book)
        # print(book)
       # 数据保存
        with open(filename + title + '.txt', mode='a', encoding='utf-8') as f:
            f.write(book)
            print('正在下载章节:  ', title)
    except Exception as e:
        print(e)
